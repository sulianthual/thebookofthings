
![alt text](screenshot.png?raw=true "Screenshot")

<h4>The Book of Things</h4>

code by Sulian Thual (2020)

A simple adventure game with a twist: you draw and name everything! Made this to learn object-oriented programming (OOP) with python in a fun way. WIP


references: https://github.com/sulianthual/thebookofthings

<h4>Instructions:</h4> 

1) You need python 3 installed as well as python module: pygame. 


2) Run the file main.py to execute: $ python -m main.py


